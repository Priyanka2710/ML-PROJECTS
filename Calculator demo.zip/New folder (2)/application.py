from flask import Flask,request,jsonify,render_template

#request.json is use to get json data, jsonify use to give result in json format
app=Flask(__name__) #to create a app name flask , flask is framework content libraries and methods

@app.route("/", methods=['GET', 'POST'])           #called to webbrowser with method to get
def index():
    return render_template('index.html')      #redirect to our html page we get our front page here


@app.route('/math', methods=['POST'])  # This will be called from UI
def math_operation():
    if (request.method=='POST'):
        operation=request.form['operation']
        num1 =int(request.form['num1'])
        num2 = int(request.form['num2'])
        if(operation=='add'):
            r= num1+num2
            result= 'the sum of '+str(num1)+' and '+str(num2) +' is '+str(r)
        if (operation == 'subtract'):
            r = num1 - num2
            result = 'the difference of ' + str(num1) + ' and ' + str(num2) + ' is ' + str(r)
        if (operation == 'multiply'):
            r = num1 * num2
            result = 'the product of ' + str(num1) + ' and ' + str(num2) + ' is ' + str(r)
        if (operation == 'divide'):
            r = num1 / num2
            result = 'the quotient when ' + str(num1) + ' is divided by ' + str(num2) + ' is ' + str(r)
        return render_template('result.html',result = result)





if __name__ == '__main__':
    app.run(debug=True)